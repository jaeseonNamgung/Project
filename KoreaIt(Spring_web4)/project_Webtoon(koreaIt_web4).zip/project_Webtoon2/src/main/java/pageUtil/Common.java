package pageUtil;

public class Common {
	
	public static class Board{
		
		
		// 한 페이지에 보여줄 게시물 수 
		public final static int BLOCKLIST = 5;
		
		// 한 화면에 보여질 페이지 메뉴의 수
		//< 1 2 3 >
		public final static int BLOCKPAGE = 5;
		
	}
	
}
