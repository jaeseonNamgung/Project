package vo;

public class BookmarkVO {
	
	private int idx;
	private String user2_id;
	private int toon_idx;
	
	public int getToon_idx() {
		return toon_idx;
	}
	public void setToon_idx(int toon_idx) {
		this.toon_idx = toon_idx;
	}
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getUser2_id() {
		return user2_id;
	}
	public void setUser2_id(String user2_id) {
		this.user2_id = user2_id;
	}
	
	
	
	
	
}
